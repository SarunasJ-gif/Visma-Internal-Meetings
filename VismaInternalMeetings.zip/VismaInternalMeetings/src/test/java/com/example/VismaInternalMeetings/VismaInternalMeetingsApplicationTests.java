package com.example.VismaInternalMeetings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VismaInternalMeetingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
