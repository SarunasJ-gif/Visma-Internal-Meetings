package com.example.VismaInternalMeetings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VismaInternalMeetingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(VismaInternalMeetingsApplication.class, args);
	}

}
